#include <iostream>
using namespace std;
void printOut(string word){
  int vowels=0;
  int consenant=0;
  int numberLength=word.length();
    for(int index=0;index<word.length();index++){
      if(word[index]=='a' ||word[index]=='e'||word[index]=='i'||word[index]=='o'||word[index]=='u'||word[index]=='y'||word[index]=='A' ||word[index]=='E'||word[index]=='I'||word[index]=='O'||word[index]=='U'||word[index]=='Y'){
        vowels++;
    }else{

      consenant++;
     }

    }

    cout<<"The word"<<" "<<word<<" "<<"contains"<<" "<<vowels<<" "<< "vowels"<<" "<< "and"<<" "<<consenant<<" "<<" consonants"<<" "<<endl;

}

int main() {
  string word;
cout<<"please Enter the word"<<endl;
cin>>word;
 printOut( word);
}
//the differtiate of vowels and consenante